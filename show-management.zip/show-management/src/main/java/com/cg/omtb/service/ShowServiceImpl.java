package com.cg.omtb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.omtb.dao.ShowRepository;
import com.cg.omtb.entity.ShowEntity;
import com.cg.omtb.exception.ShowException;

@Service
public class ShowServiceImpl implements ShowService{

	@Autowired
	ShowRepository repo;
	
	@Override
	//this function adds a show
	public ShowEntity addShow(ShowEntity show) throws ShowException {
		if(show==null) {
			throw new ShowException("show Should not be null");
		}
		return repo.save(show);
	}

	@Override
	//this function deletes a show as per given id
	public void deleteShow(Integer showId) throws ShowException {
		if(!repo.existsById(showId)) {
			throw new ShowException("show does not exists");
		}
		
		repo.deleteById(showId);
	}

	@Override
	//this function finds a show as per given id
	public ShowEntity findShow(Integer showId)  throws ShowException{
		ShowEntity show = repo.findById(showId).orElse(null);
		if(show == null) {
			throw new ShowException("this showId doesnt exists");
		}
		return repo.findById(showId).orElse(null);
	}

	@Override
	//this function returns all the shows in the theater
	public List<ShowEntity> findShowInTheater(Integer theaterId) throws ShowException{
		List<ShowEntity> shows = repo.findByTheaterId(theaterId);
		if(shows == null) {
			throw new ShowException("no show today in this theater");
		}
		return repo.findByTheaterId(theaterId);
	}

}
