package com.cg.omtb.service;

import java.util.List;

import com.cg.omtb.entity.ShowEntity;
import com.cg.omtb.exception.ShowException;


public interface ShowService {
	
	ShowEntity addShow(ShowEntity show) throws ShowException;
	
	void deleteShow(Integer id) throws ShowException;
	
	ShowEntity findShow(Integer id) throws ShowException;

	List<ShowEntity> findShowInTheater(Integer theaterId) throws ShowException;
}
