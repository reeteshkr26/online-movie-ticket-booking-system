package com.cg.omtb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan("com")
@SpringBootApplication
public class showManagement {

	public static void main(String[] args) {
		SpringApplication.run(showManagement.class, args);
	}

}
