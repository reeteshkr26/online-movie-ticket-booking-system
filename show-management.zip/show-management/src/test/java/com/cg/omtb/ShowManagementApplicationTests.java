package com.cg.omtb;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.cg.omtb.dao.ShowRepository;
import com.cg.omtb.entity.ShowEntity;
import com.cg.omtb.exception.ShowException;
import com.cg.omtb.model.ShowModel;
import com.cg.omtb.service.ShowService;

@SpringBootTest
@RunWith(SpringRunner.class)
public class ShowManagementApplicationTests {

	@Autowired
	private ShowService servicer;
	
	@MockBean
	private ShowRepository repo;

	@Before
	public void init() {

	}
	
	@Test
	public void addShow() throws ShowException{
		//ShowEntity show = new ShowEntity("11:32","9:30", "evening", 123,456,987);
		ShowEntity show = new ShowEntity("11:32","9:30", "evening", 123,456,987);
		when(repo.save(show)).thenReturn(show);
		assertEquals(show, servicer.addShow(show));
	}
	
//	@Test
//	public void testAddShow_NullPointerException() throws ShowException{
//		ShowEntity show = getShow();
//		when(repo.save(show)).thenReturn(null);
//		assertThrows(ShowException.class,
//				()->{
//					servicer.addShow(null);
//				}
//		);
//		
//	}
	
//	@Test
//	public void testDeleteShow_ShowNotExist() throws ShowException {
//		
//		when(!repo.existsById(anyInt())).thenReturn(false);
//		
//		assertThrows(ShowException.class,
//				()->{
//					servicer.deleteShow(1011);
//				}
//		);
//	}
//	
//	@Test
//	public void findShowByIdTest() throws ShowException{
//		ShowEntity show = getShow();
//		when(repo.findByShowId(anyInt())).thenReturn(show);
//		ShowEntity showFound = servicer.findShow(12345);
//		assertNotNull(showFound);
//		assertEquals(showFound, show);
//	}
//	
	@Test
	public void deleteShowTest() throws ShowException {
		when(repo.existsById(anyInt())).thenReturn(true);
		servicer.deleteShow(32727);
		verify(repo,times(1)).deleteById(anyInt());
	}
	
	public ShowEntity getShow() {
		ShowEntity show = new ShowEntity();
		show.setShowId(12345);
		show.setEndTime("1:30");
		show.setMovieId(9876);
		show.setScreenId(4567);
		show.setShowName("evening");
		show.setStartTime("10:30");
		show.setTheaterId(5342);
		return show;
	}
}
