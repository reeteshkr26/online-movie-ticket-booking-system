/**********************************************************************************************************************************
 -File Name         :   TheaterManagementServiceApplicationTests
 -Author            :   Sanjeev Kumar Yaduwanshi
 -Creation Date     :   22-09-2020
 -Description       :   This class is to test all the test cases.
 **********************************************************************************************************************************/


package com.cg.omtb;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.cg.omtb.dao.TheaterRepository;
import com.cg.omtb.entity.TheaterEntity;
import com.cg.omtb.exception.TheaterException;
import com.cg.omtb.model.TheaterModel;
import com.cg.omtb.service.TheaterService;

@SpringBootTest
@RunWith(SpringRunner.class)
public class TheaterManagementServiceApplicationTests {
	
	@Autowired
	private TheaterService service;

	@MockBean
	private TheaterRepository repo;
	
	TheaterModel theaterModel = null;
	
	@Before
	public void init() {
		theaterModel=new TheaterModel(2001,"ansal","NOIDA","Viraj","5885588585");
	}
	
	@Test
	public void addTheaterTest() throws TheaterException{
		TheaterEntity theater=of(theaterModel);
		when(repo.save(theater)).thenReturn(theater);
		
		TheaterModel model=service.addTheater(theater);
		assertEquals(theater.getTheaterId(),model.getTheaterId());
	}
	
	@Test
	public void testAddTheater_NullPointerException() throws TheaterException{
		
	

		assertThrows(TheaterException.class,
				()->{
					service.addTheater(null);
				}
		);
		
/*		*****TDD Approach*****
		
		when(repo.save(theater)).thenReturn(null);
		
		TheaterModel model=service.addTheater(theater);
		if(model==null) {
			throw new TheaterException("Theater should not be null...");
		}
*/		
		
	}

	@Test
	public void testAddTheater_TheaterAlreadyExist() throws TheaterException{
		TheaterEntity theater=of(theaterModel);
		when(repo.findByTheaterId(theater.getTheaterId())).thenReturn(theater);
		
		assertThrows(TheaterException.class, ()-> service.addTheater(theater));
	
/*		
 * *****TDD Approach*****
		TheaterModel model=service.addTheater(theater);
		if(model!=null) {
			throw new TheaterException("Theater already exist...");
		}
*/
		
	}
	
	
	@Test
	public void deleteTheaterTest() throws TheaterException {
		when(repo.existsById(2001)).thenReturn(true);
		service.deleteTheater(2001);
		verify(repo).deleteById(2001);
	}
	
	@Test
	public void testDeleteTheater_TheaterNotExist() {
		when(repo.existsById(2021)).thenReturn(false);
		
		assertThrows(TheaterException.class, ()-> service.deleteTheater(2021));
		
	}
	
	
	@Test
	public void findTheaterTest() throws TheaterException {
		TheaterEntity theater=of(theaterModel);
		
		when(repo.findByTheaterId(2001)).thenReturn(theater);
		TheaterModel model=service.findTheater(2001);
		//assertNotNull(movieModel);
		assertEquals("ansal", model.getTheaterName());
	}
	
	@Test
	public void testFindTheater_TheaterNotExist() {
		when(repo.findByTheaterId(2001)).thenReturn(null);
		assertThrows(TheaterException.class, ()-> service.findTheater(2001));
	}
	
	public TheaterEntity of(TheaterModel source) {
		
		TheaterEntity result=null;
		if(source!=null) {
			result=new TheaterEntity();
			result.setTheaterId(source.getTheaterId());
			result.setTheaterName(source.getTheaterName());
			result.setTheaterCity(source.getTheaterCity());
			result.setManagerName(source.getManagerName());
			result.setManagerContact(source.getManagerContact());
		}
		return result;
	}
}
