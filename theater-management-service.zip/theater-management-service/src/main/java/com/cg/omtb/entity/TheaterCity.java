package com.cg.omtb.entity;

public enum TheaterCity {
	
	GREATERNOIDA, GHAZIABAD, NOIDA, MEERUT, MODINAGAR;

}
