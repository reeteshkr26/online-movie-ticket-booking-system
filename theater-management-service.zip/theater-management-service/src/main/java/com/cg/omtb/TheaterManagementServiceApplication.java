package com.cg.omtb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheaterManagementServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheaterManagementServiceApplication.class, args);
	}

}
