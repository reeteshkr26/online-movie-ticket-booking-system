
/**********************************************************************************************************************************
 -File Name         :   TicketModel.class
 -Author            :   Reetesh Kumar Mandal
 -Creation Date     :   24-09-2020
 -Description       :   Modal class of Booking management service
 **********************************************************************************************************************************/

package com.cg.omtb.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class TicketModel {

	private Integer ticketId;
	
	@NotNull(message = "no. of seats is mandatory")
	private Integer noOfSeats;

	@NotNull(message = "Booking id is mandatory")
	private long bookingId;
	
	@NotNull(message = "ticket status is mandatory")
	private Integer ticketStatus;

	@NotBlank(message = "Screen Name is mandatory")
	private String screenName;
	
	@NotNull(message = "Customer is mandatory")
	private Integer customerId;
	
	private Double totalTicketPrice;

	public Integer getTicketId() {
		return ticketId;
	}

	public void setTicketId(Integer ticketId) {
		this.ticketId = ticketId;
	}

	public Integer getNoOfSeats() {
		return noOfSeats;
	}

	public void setNoOfSeats(Integer noOfSeats) {
		this.noOfSeats = noOfSeats;
	}

	public long getBookingId() {
		return bookingId;
	}

	public void setBookingId(long bookingId) {
		this.bookingId = bookingId;
	}

	public Integer getTicketStatus() {
		return ticketStatus;
	}

	public void setTicketStatus(Integer ticketStatus) {
		this.ticketStatus = ticketStatus;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Double getTotalTicketPrice() {
		return totalTicketPrice;
	}

	public void setTotalTicketPrice(Double totalTicketPrice) {
		this.totalTicketPrice = totalTicketPrice;
	}
	
	
	
}
