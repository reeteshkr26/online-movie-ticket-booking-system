
/**********************************************************************************************************************************
 -File Name         :   TicketEntity.class
 -Author            :   Reetesh Kumar Mandal
 -Creation Date     :   24-09-2020
 -Description       :   Entity class used to create the table instance of object 
 **********************************************************************************************************************************/

package com.cg.omtb.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="ticket_table")
public class TicketEntity {

	@Id
	@Column(name="ticket_id")
	private Integer ticketId;
	
	@Column(name="no_of_seats", nullable=false)
	@NotNull(message = "no. of seats is mandatory")
	private Integer noOfSeats;
	
	@Column(name="booking_id",nullable=false)
	@NotNull(message = "Booking id is mandatory")
	private Long bookingId;
	
	@Column(name="ticket_status",nullable=false)
	@NotNull(message = "ticket status is mandatory")
	private Integer ticketStatus;
	
	@Column(name="screen_name",nullable=false)
	@NotBlank(message = "Screen Name is mandatory")
	private String screenName;
	
	@Column(name="customer_id",nullable=false)
	@NotNull(message = "Customer is mandatory")
	private Integer customerId;
	
	@Column(name="total_ticket_price",nullable=false)
	private Double totalTicketPrice;
	
	public Integer getTicketId() {
		return ticketId;
	}

	public void setTicketId(Integer ticketId) {
		this.ticketId = ticketId;
	}

	public Integer getNoOfSeats() {
		return noOfSeats;
	}

	public void setNoOfSeats(Integer noOfSeats) {
		this.noOfSeats = noOfSeats;
	}

	public Long getBookingId() {
		return bookingId;
	}

	public void setBookingId(Long bookingId2) {
		this.bookingId = bookingId2;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}
	
	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getTicketStatus() {
		return ticketStatus;
	}

	public void setTicketStatus(Integer ticketStatus) {
		this.ticketStatus = ticketStatus;
	}

	public Double getTotalTicketPrice() {
		return totalTicketPrice;
	}

	public void setTotalTicketPrice(Double totalTicketPrice) {
		this.totalTicketPrice = totalTicketPrice;
	}

	
	
	
	
}
