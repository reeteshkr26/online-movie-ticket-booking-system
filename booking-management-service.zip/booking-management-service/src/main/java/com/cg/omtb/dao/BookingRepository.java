/**********************************************************************************************************************************
 -File Name         :   Booking Repository Interface
 -Author            :   Reetesh Kumar Mandal
 -Creation Date     :   24-09-2020
 -Description       :   Repository interface used to connect to the database 
 **********************************************************************************************************************************/
package com.cg.omtb.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.omtb.entity.BookingEntity;

public interface BookingRepository extends JpaRepository<BookingEntity, Long>{

}
