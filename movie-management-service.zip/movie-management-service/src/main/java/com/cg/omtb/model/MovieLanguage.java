package com.cg.omtb.model;

public enum MovieLanguage {

	HINDI,ENGLISH,SPANISH,TELGU,BHOJPURI,MARATHI,BENGALI;
}
