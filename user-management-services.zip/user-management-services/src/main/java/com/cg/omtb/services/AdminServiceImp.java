package com.cg.omtb.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.omtb.dao.AdminRepo;
import com.cg.omtb.entity.AdminEntity;
import com.cg.omtb.exception.AdminException;
import com.cg.omtb.model.AdminModel;

@Service
public class AdminServiceImp implements AdminService{

	@Autowired
	private AdminRepo adminRepo;
	
	private AdminModel of(AdminEntity source) {
		AdminModel result=null;
		if(source!=null) {
			result=new AdminModel();
			result.setAdminId(source.getAdminId());
			result.setPassword(source.getPassword());
			result.setEmail(source.getEmail());
			result.setPhoneNo(source.getPhoneNo());
			result.setAdminProfile(source.getAdminProfile());
			result.setLoginToken(source.getLoginToken());
		}
		return result;
	}
	private AdminEntity of(AdminModel source) {
		AdminEntity result=null;
		if(source!=null) {
			result=new AdminEntity();
			result.setAdminId(source.getAdminId());
			result.setPassword(source.getPassword());
			result.setEmail(source.getEmail());
			result.setPhoneNo(source.getPhoneNo());
			result.setAdminProfile(source.getAdminProfile());
			result.setLoginToken(source.getLoginToken());
		}
		return result;
	}
	
	@Override
	public AdminModel adminRegistration(AdminModel admin) throws AdminException{
		if(admin!=null) {
			if(adminRepo.existsById(admin.getAdminId())) {
				throw new AdminException("Administrator have already registered !");
			}
			else if(adminRepo.existsByEmail(admin.getEmail())) {
				throw new AdminException("Email already have already registered !");
			}
			else if(adminRepo.existsByPhoneNo(admin.getPhoneNo())) {
				throw new AdminException("Phone Number have already registered !");
			}
			else {
				admin=of(adminRepo.save(of(admin)));
			}
		}
	
		return admin;
	}

	@Override
	public AdminModel adminLogin(String adminId, String password)  throws AdminException{
		AdminEntity admin=adminRepo.getAdmin(adminId, password);
		if(admin!=null) {
			return of(admin);
		}
		else {
			return null;
		}
		
	}
}
