package com.cg.omtb.model;

public class AdminModel {
	
	private String adminId;
	private String password;
	private String email;
	private String phoneNo;
	private String loginToken;
	private String adminProfile;
	
	public String getAdminId() {
		return adminId;
	}
	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getLoginToken() {
		return loginToken;
	}
	public void setLoginToken(String loginToken) {
		this.loginToken = loginToken;
	}
	public String getAdminProfile() {
		return adminProfile;
	}
	public void setAdminProfile(String adminProfile) {
		this.adminProfile = adminProfile;
	}

}
