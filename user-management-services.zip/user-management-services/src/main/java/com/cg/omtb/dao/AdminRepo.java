package com.cg.omtb.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.omtb.entity.AdminEntity;

public interface AdminRepo extends JpaRepository<AdminEntity,String> {
	
	boolean existsByEmail(String email);
	boolean existsByPhoneNo(String phoneNo);
	
	@Query("SELECT a FROM AdminEntity a WHERE a.adminId=:aId AND a.password=:pass")
	public AdminEntity getAdmin(@Param("aId") String adminId,@Param("pass") String password);

}
