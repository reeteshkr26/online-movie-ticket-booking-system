package com.cg.omtb.services;

import com.cg.omtb.exception.UserException;
import com.cg.omtb.model.UserModel;

public interface UserService {
	
	public UserModel userRegistration(UserModel user)  throws UserException;
	public UserModel userLogin(String userId, String password)  throws UserException;

}