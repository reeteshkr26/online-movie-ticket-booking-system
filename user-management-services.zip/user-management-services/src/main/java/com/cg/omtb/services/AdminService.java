package com.cg.omtb.services;

import com.cg.omtb.exception.AdminException;
import com.cg.omtb.model.AdminModel;

public interface AdminService {

	public AdminModel adminRegistration(AdminModel admin)  throws AdminException;
	public AdminModel adminLogin(String adminId, String password)  throws AdminException;
}
