package com.cg.omtb.service;

import java.util.List;

import com.cg.omtb.entity.ScreenEntity;
import com.cg.omtb.exception.ScreenException;
import com.cg.omtb.model.ScreenModel;

public interface ScreenService {

	
	List<ScreenModel> findAll();
    void deleteById(long screenId) throws ScreenException;
    ScreenModel save(ScreenEntity model) throws ScreenException;
    ScreenModel findByScreenId(Long screenId)throws ScreenException;
    ScreenModel updateScreen(int bookedSeat,long screenId);
    
    //finding screen by the help of theatre information
//	List<ScreenModel> findByTheaterName(String theaterName) throws ScreenException;
//	List<ScreenModel> findByTheaterId(Long theatreId) throws ScreenException;
	
}
