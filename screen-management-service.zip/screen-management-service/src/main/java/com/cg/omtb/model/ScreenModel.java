package com.cg.omtb.model;



public class ScreenModel {
	
	
	public ScreenModel() {
		
	}
	
	
    public ScreenModel(String screenName, Integer numberOfSeats, Integer availableSeats, Long theatreId) {
		super();
		this.screenName = screenName;
		this.numberOfSeats = numberOfSeats;
		AvailableSeats = availableSeats;
		this.theatreId = theatreId;
	}


	public ScreenModel(Long screenId, String screenName, Integer numberOfSeats, Integer availableSeats,
			Long theatreId) {
		super();
		this.screenId = screenId;
		this.screenName = screenName;
		this.numberOfSeats = numberOfSeats;
		AvailableSeats = availableSeats;
		this.theatreId = theatreId;
	}
	private Long screenId;
	
	private String screenName;

    private Integer numberOfSeats;
    
	 private Integer AvailableSeats;
	
	private Long theatreId;

    public Long getScreenId() {
        return screenId;
    }
    public void setScreenId(Long screenId) {
		this.screenId = screenId;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}


	public Integer getNumberOfSeats() {
		return numberOfSeats;
	}
	public void setNumberOfSeats(Integer numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}
	public Integer getAvailableSeats() {
		return AvailableSeats;
	}
	public void setAvailableSeats(Integer availableSeats) {
		AvailableSeats = availableSeats;
	}
	public Long getTheatreId() {
		return theatreId;
	}
	public void setTheatreId(Long theatreId) {
		this.theatreId = theatreId;
	}
	
	public String toString() {
		return screenId+" "+screenName+" "+theatreId+" "+numberOfSeats+" "+AvailableSeats;
	}
	
}
