package com.cg.omtb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.omtb.model.TheatreModel;
import com.cg.omtb.service.ScreenServiceImpl;

@RestController
@RequestMapping("/theatre")
public class TheatreController {

	@Autowired
	ScreenServiceImpl service;
	
	@PostMapping
	public ResponseEntity<TheatreModel> add(@RequestBody TheatreModel model){
		model=service.add(model);
		return new ResponseEntity<>(model, HttpStatus.CREATED);
	}
	@GetMapping
	public ResponseEntity<List<TheatreModel>> findAll(){
		return new ResponseEntity<>(service.findAllTheatre(),HttpStatus.OK);
	}
}
