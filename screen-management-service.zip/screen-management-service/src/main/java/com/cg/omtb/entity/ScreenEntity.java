package com.cg.omtb.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "screen_table",uniqueConstraints={@UniqueConstraint(columnNames={"screen_name"})})
public class ScreenEntity {
	
	public ScreenEntity() {
		
	}

	public ScreenEntity(Long screenId, String screenName, Integer numberOfSeats, Integer availableSeats,
			Long theatreId) {
		super();
		this.screenId = screenId;
		this.screenName = screenName;
		this.numberOfSeats = numberOfSeats;
		this.availableSeats = availableSeats;
		this.theatreId = theatreId;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "screen_id")
    private Long screenId;
	
	@NotBlank(message="Screen name should not be null")
	@Column(name = "screen_name",nullable=false,length=4)
    private String screenName;
    
	@NotNull(message="Number of seats should not be null")
    @Column(name = "screen_no._of_seats",nullable=false)
    private Integer numberOfSeats;
    
	@NotNull(message="Should not be null")
	@Column(name = "screen_avai_seats",nullable=false)
    private Integer availableSeats;
	
	@NotNull(message="theatreId should not be null")
	@Column(name = "theatre_id",nullable=false)
	private Long theatreId;

    public Long getScreenId() {
        return screenId;
    }
    public void setScreenId(Long screenId) {
		this.screenId = screenId;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	
	
	public Integer getNumberOfSeats() {
		return numberOfSeats;
	}
	public void setNumberOfSeats(Integer numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}
	public Integer getAvailableSeats() {
		return availableSeats;
	}
	public void setAvailableSeats(Integer availableSeats) {
		this.availableSeats = availableSeats;
	}
	public Long getTheatreId() {
		return theatreId;
	}
	public void setTheatreId(Long theatreId) {
		this.theatreId = theatreId;
	}
	
	public String toString() {
		return screenId+" "+screenName+" "+theatreId+" "+numberOfSeats+" "+availableSeats;
	}
}
