package com.cg.omtb.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.omtb.entity.ScreenEntity;
import com.cg.omtb.entity.TheatreEntity;
import com.cg.omtb.exception.ScreenException;
import com.cg.omtb.model.ScreenModel;
import com.cg.omtb.model.TheatreModel;
import com.cg.omtb.repo.ScreenRepo;
import com.cg.omtb.repo.TheatreRepo;
@Service

public class ScreenServiceImpl implements ScreenService{
	@Autowired
	private ScreenRepo repo;
	
	@Autowired
	private TheatreRepo repo2;
	
	/* Following 4 functions are used to convert model
	 * and vice versa.
	 */

	public ScreenEntity modelToEntity(ScreenModel source) {
		
		ScreenEntity result=null;
		if(source!=null) {
			result=new ScreenEntity();
			result.setScreenId(source.getScreenId());
			result.setScreenName(source.getScreenName());
			result.setTheatreId(source.getTheatreId());
			result.setNumberOfSeats(source.getNumberOfSeats());
			result.setAvailableSeats(source.getAvailableSeats());
		}
		
		return result;
		}
	public TheatreEntity modelToEntity(TheatreModel source) {
		
		TheatreEntity result=null;
		if(source!=null) {
			result=new TheatreEntity();
			BeanUtils.copyProperties(source, result);
		}
		
		return result;
		}
		
	
	public ScreenModel entityToModel(ScreenEntity source) {
		
		ScreenModel result=null;
		if(source!=null) {
			result=new ScreenModel();
			result.setScreenId(source.getScreenId());
			result.setScreenName(source.getScreenName());
			result.setTheatreId(source.getTheatreId());
			result.setNumberOfSeats(source.getNumberOfSeats());
			result.setAvailableSeats(source.getAvailableSeats());
			}
		
		return result;
		}
		
	public TheatreModel entityToModel(TheatreEntity source) {
		
		TheatreModel result=null;
		if(source!=null) {
			result=new TheatreModel();
			BeanUtils.copyProperties(source, result);
			}
		
		return result;
		}
		
	//Following function is used to save the screen in screen repository
	
	@Override
		public ScreenModel save(ScreenEntity model) throws ScreenException{
			if(model==null) {
				throw new ScreenException("Screen should not be null");
			}
			
			if(repo.findByScreenName(model.getScreenName())!=null) {
				throw new ScreenException("Screen Already Exist");
			}
			
			if(!repo2.existsById(model.getTheatreId())) {
				throw new ScreenException("theater ID is invalid ");
					
			}
			ScreenEntity entity=repo.save(model);
			return entityToModel(entity);
		}
	
	
	/* Following function is used to find all the
	 *  screen available in screen repository 
	 */
	@Override
	public List<ScreenModel> findAll() {
		return repo.findAll().stream().map(entity->entityToModel(entity)).collect(Collectors.toList());
	}
	
	
	/*Following Function is used to update the screen 
	 * i.e. to update the Available_seats Attribute after
	 * booking happened.
	 * 
	 */
	@Override
	public ScreenModel updateScreen(int bookedSeat,long screenId) {
		
		ScreenEntity entity=repo.findByScreenId(screenId);
		entity.setAvailableSeats(entity.getAvailableSeats()-bookedSeat);
		
		return entityToModel(repo.save(entity));
		
	}

	
	// following function is used to delete an instance from screen repository.
	@Override
	public void deleteById(long screenId) throws ScreenException {
		if(repo.existsById(screenId)) {
			repo.deleteById(screenId);
			
		}else {
			throw new ScreenException("Screen Id is Invalid");
		}
		
	}

	

	
	@Override
	public ScreenModel findByScreenId(Long screenId) throws ScreenException{
		
		ScreenModel model= entityToModel(repo.findByScreenId(screenId));
		if(model!=null) {
		return model;
	}
		else {
			throw new ScreenException("Cannot find Screen");
		}
	}
	
	/*
	 * Following are the complementary methods which can be used during integration
	 */

//	@Override
//	public List<ScreenModel> findByTheaterId(Long theatreId) throws ScreenException {
//		if(theatreId==null) {
//			throw new ScreenException("theater Id doesnt exist");
//		}else {
//			return repo.findAllByTheatreId(theatreId).stream()
//				          .map(entity -> entityToModel(entity)).collect(Collectors.toList());
//		}
//	}
//	@Override
//		public List<ScreenModel> findByTheaterName(String theatreName) throws ScreenException {
//			List<TheatreEntity> theaterModelList=repo2.findByTheatreName(theatreName);
//			
//			List<ScreenModel> finalList=new ArrayList<ScreenModel>();
//			for(TheatreEntity theaterModel:theaterModelList) {
//				
//				finalList.addAll(repo.findAllByTheatreId(theaterModel.getTheatreID()).stream()
//						.map(entity -> entityToModel(entity)).collect(Collectors.toList()));
//			
//			}
//			return finalList;
//		}
	
	
	/*
	 * extra for theatre methods 
	 */
	public TheatreModel add(TheatreModel model) {
			  return entityToModel(repo2.save(modelToEntity(model)));
		}
		public List<TheatreModel> findAllTheatre() {
			 return repo2.findAll().stream().map(e -> entityToModel(e)).collect(Collectors.toList());
		}
}
