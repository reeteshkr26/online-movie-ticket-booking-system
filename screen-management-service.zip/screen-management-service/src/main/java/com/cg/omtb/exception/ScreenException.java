package com.cg.omtb.exception;

public class ScreenException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ScreenException(String message) {
		super(message);
	}
	
}
