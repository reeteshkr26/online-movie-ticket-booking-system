package com.cg.omtb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.omtb.entity.ScreenEntity;
import com.cg.omtb.exception.ScreenException;
import com.cg.omtb.model.ScreenModel;
import com.cg.omtb.service.ScreenService;

@RestController
@RequestMapping("/screen")
public class ScreenController {
	@Autowired
	private ScreenService service;
	
	
	@GetMapping
	public ResponseEntity<List<ScreenModel>> findAllScreen(){
		
		return new ResponseEntity<>(service.findAll(),HttpStatus.OK); 
		
	}
	
	@PostMapping
	public ResponseEntity<ScreenModel> saveScreen( @RequestBody ScreenEntity model) throws ScreenException{
		return new ResponseEntity<>(service.save(model),HttpStatus.CREATED);
	}
	
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteScreen(@PathVariable("id") Long screenId) throws ScreenException{
		
		service.deleteById(screenId);
		return new ResponseEntity<>("Screen Deleted",HttpStatus.OK);
	}
	
	
	@PutMapping("/{bookedSeat}/{screenId}")
	public ResponseEntity<ScreenModel> updateScreen( @PathVariable int bookedSeat,@PathVariable long screenId){
		
		return new ResponseEntity<>(service.updateScreen(bookedSeat,screenId),HttpStatus.OK);
	}
	
	
//	@GetMapping("/theatreName/{theatreName}")
//	public ResponseEntity<List<ScreenModel>> findScreenByTheaterName(@PathVariable("theaterName") String theaterName) throws ScreenException{
//		
//		return new ResponseEntity<List<ScreenModel>>(service.findByTheaterName(theaterName),HttpStatus.ACCEPTED);
//	}
//	
//	@GetMapping("/theatreId/{theatreId}")
//	public ResponseEntity<List<ScreenModel>> findScreenByTheaterId(@PathVariable("theatreId") Long theatreId) throws ScreenException{
//		
//		return new ResponseEntity<List<ScreenModel>>(service.findByTheaterId(theatreId),HttpStatus.ACCEPTED);
//	}
	

	@GetMapping("/{id}")
	public ResponseEntity<ScreenModel> findScreenByScreenId(@PathVariable("id") Long screenId) throws ScreenException{
		return new ResponseEntity<>(service.findByScreenId(screenId),HttpStatus.ACCEPTED);
	}

	

}
