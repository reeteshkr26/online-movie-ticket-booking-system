package com.cg.omtb.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.omtb.entity.ScreenEntity;
@Repository
public interface ScreenRepo extends JpaRepository<ScreenEntity,Long> {

	List<ScreenEntity> findAllByTheatreId(long theatreID);
	ScreenEntity findByScreenName(String screenName);
	ScreenEntity findByScreenId(Long screenId);
}
