package com.cg.omtb;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.cg.omtb.entity.ScreenEntity;
import com.cg.omtb.exception.ScreenException;
import com.cg.omtb.model.ScreenModel;
import com.cg.omtb.repo.ScreenRepo;
import com.cg.omtb.service.ScreenServiceImpl;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ScreenManagementServiceApplicationTests {

	
	@Autowired
	private ScreenServiceImpl service;
	
	@MockBean
	private ScreenRepo repo;
	
	
	@Before
	public void init() {

	}
	
	@Test
	public void getScreenTest() {
		when(repo.findAll()).thenReturn(Stream.of(new ScreenEntity((long)1,"SC01",20,20,(long)2006), 
				new ScreenEntity((long)1,"SC01",7,20,(long)2006)).collect(Collectors.toList()));
		assertEquals(2,service.findAll().size());
	}
	
	@Test
	public void saveScreenTest() throws ScreenException {
		ScreenEntity entity=service.modelToEntity(getScreen());
		when(repo.save(entity)).thenReturn(entity);
		ScreenModel model=service.save(entity);
		assertEquals(entity.getScreenId(),model.getScreenId());
	}
	
	@Test
	public void testSaveScreen_NullPointerException() throws ScreenException {
	   ScreenEntity screen=service.modelToEntity(getScreen());
	   
		when(repo.save(screen)).thenReturn(null);
		assertThrows(ScreenException.class,
				()->{
					service.save(null);
				}
		);
	}
	
	@Test
	public void testScreenSave_ScreenAlreadyExist() throws ScreenException {
		 ScreenEntity screen=service.modelToEntity(getScreen());
		 
		when(repo.findByScreenName(anyString())).thenReturn(screen);
		
		assertThrows(ScreenException.class,
				()->{
					service.save(screen);
				}
		);
	}
//	@Test
//	public void testScreenSave_theatreIdNotExist() throws ScreenException {
//		 ScreenEntity screen=service.modelToEntity(getScreen());
//		 
//		when(repo2.existsById(anyLong())).thenReturn(false);
//		
//		assertThrows(ScreenException.class,
//				()->{
//					service.save(screen);
//				}
//		);
//	}
	
	
	@Test
	public void deleteScreenTest() throws ScreenException {
		when(repo.existsById(anyLong())).thenReturn(true);
		service.deleteById(1011);
		verify(repo,times(1)).deleteById(anyLong());
	}
	
	
	@Test
	public void testDeleteScreen_ScreenNotExist() throws ScreenException {
		
		when(!repo.existsById(anyLong())).thenReturn(false);
		
		assertThrows(ScreenException.class,
				()->{
					service.deleteById(1011);
				}
		);
	}
	
	
	
	@Test
	public void findScreenByIdTest() throws ScreenException {
		ScreenEntity screen=service.modelToEntity(getScreen());
		
		when(repo.findByScreenId(anyLong())).thenReturn(screen);
		ScreenModel screenModel=service.findByScreenId(1234l);
		assertNotNull(screenModel);
		assertEquals(103l, screenModel.getScreenId());
	}
	
	@Test
	public void testFindScreenById_ScreenIdNotExist() throws ScreenException {
		
		when(repo.findByScreenId(anyLong())).thenReturn(null);
		
		assertThrows(ScreenException.class,
				()->{
					service.findByScreenId(1234l);
				}
		);

	}
	
	
	
	
	public ScreenModel getScreen() {
	
		ScreenModel model=new ScreenModel();
		model.setScreenId(103l);
		model.setScreenName("SC01");
		model.setTheatreId(2008l);
		model.setNumberOfSeats(20);
		model.setAvailableSeats(20);
		return model;
	}
	
	
}
